
public class ClasseCargo {
	
	String numeroContaAt;
	float saldoContaAt;
	
	// Construtor para adicionar 2 parâmetros.
	public ClasseCargo(String numeroPar, float saldoPar) {
		this.numeroContaAt = numeroPar;
		this.saldoContaAt = saldoPar;
	}
	

}
