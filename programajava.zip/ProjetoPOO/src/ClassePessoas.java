
public class ClassePessoas {

	// Atributos
	private String nomeAt;
	private String documentoAt;
	private float rendaAt;
	
	//Construtores: Quando criar objeto obriga a colocar os parâmetros
	public ClassePessoas(String nomePar, String documentoPar, 
			float rendaPar) {
		
		this.nomeAt = nomePar;
		this.documentoAt = documentoPar;
		this.rendaAt = rendaPar;
	}
	//Contrutor 2:
	public ClassePessoas(String nomePar) {
		this.nomeAt = nomePar;
	}
	
	
	
}
