
public class ClassePessoas {

	// Atributos
	private String nomeAt;
	private String documentoAt;
	private float rendaAt;
	
	//Construtores: Quando criar objeto obriga a colocar os parâmetros
	public ClassePessoas(String nomePar, String documentoPar, 
			float rendaPar) {
		
		this.nomeAt = nomePar;
		this.documentoAt = documentoPar;
		this.rendaAt = rendaPar;
	}
	//Contrutor 2:
	public ClassePessoas(String nomePar) {
		this.nomeAt = nomePar;
	}
	
	//Setters
	public void alterarNome(String nomePar) {
		this.nomeAt = nomePar;
	}
	public void alterarDocumento(String documentoPar) {
		this.documentoAt = documentoPar;
	}
	public void alterarRenda(float rendaPar) {
		this.rendaAt = rendaPar;
	}
	//Getters
	public String pegarNome() {
		return nomeAt;
	}
	public String pegarDocument() {
		return documentoAt;
	}
	public float pegarRenda() {
		return rendaAt;
	}
}
