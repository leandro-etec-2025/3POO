
public class ClasseClientes extends ClassePessoas{

	boolean negativaAt;
	
	// Agregação
	ClasseCargo cargoAt;
	
	// Construtor
	public ClasseClientes(String nomePar, String documentoPar,
			float rendaPar, boolean negativadoPar) {
		
		super(nomePar, documentoPar, rendaPar);
		
		this.negativaAt = negativadoPar;
		
	}


	
	
}
