
public class ClasseFuncionarios extends ClassePessoas{
	
	String cargoAt;
	
	// Construtor
	public ClasseFuncionarios(String nome, String documento, 
			float renda, String cargoPar) {
		super(nome, documento, renda);
		
		this.cargoAt = cargoPar;
		
	}
	
	//Setters: Alterar
	public void alterarCargo(String cargoPar) {
		this.cargoAt = cargoPar;
	}
		

}
