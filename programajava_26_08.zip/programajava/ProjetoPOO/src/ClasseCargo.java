
public class ClasseCargo {
	
	String numeroContaAt;
	float saldoContaAt;
	
	// Construtor para adicionar 2 parâmetros.
	public ClasseCargo(String numeroPar, float saldoPar) {
		this.numeroContaAt = numeroPar;
		this.saldoContaAt = saldoPar;
	}
	
	//Setters
	public void alterarNumero(String numeroPar) {
		this.numeroContaAt = numeroPar;
	}
	
	public void alterarSaldo(float saldoPar) {
		this.saldoContaAt = saldoPar;
	}
	//Getters
	public String pegarNumero() {
		return numeroContaAt;
	}
	public float pegarSaldo() {
		return saldoContaAt;
	}

}
