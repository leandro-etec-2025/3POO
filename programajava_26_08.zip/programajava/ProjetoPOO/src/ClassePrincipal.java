
public class ClassePrincipal {

	public static void main(String[] args) {


		//Instanciar objeto
		ClassePessoas p1 = new ClassePessoas("Leandro", "123", 1600);

		ClassePessoas p2 = new ClassePessoas("César");

		ClasseClientes c1 = new ClasseClientes("Mel", "123.45");
		
	}

}
