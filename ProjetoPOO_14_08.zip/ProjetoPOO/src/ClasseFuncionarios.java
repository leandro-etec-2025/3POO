
public class ClasseFuncionarios extends ClassePessoas{

	String cargoAt;
	
	// Construtor
	public ClasseFuncionarios(String nome, String documento, 
			float renda, String cargo) {
		super(nome, documento, renda);
		
		this.cargoAt = cargo;
		
	}
}
