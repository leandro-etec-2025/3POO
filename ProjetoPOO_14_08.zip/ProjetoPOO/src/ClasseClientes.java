
public class ClasseClientes extends ClassePessoas{

	boolean negativadoAt;
	
	// Construtor
	public ClasseClientes(String nome, String documento, float renda, 
			boolean negativado) {
		super(nome, documento, renda);
		
		this.negativadoAt = negativado;
		
	}
}
