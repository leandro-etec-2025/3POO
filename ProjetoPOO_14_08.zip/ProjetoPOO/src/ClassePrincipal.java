
public class ClassePrincipal {

	public static void main(String[] args) {
		//OBJETO
		
		ClasseFuncionarios func1 = new 
				ClasseFuncionarios("João", "123", 20_000, "Gerente");
		
		ClasseClientes cli1 = new ClasseClientes("Pedro", 
				"321", 2500, false);
		
		
	}

}
